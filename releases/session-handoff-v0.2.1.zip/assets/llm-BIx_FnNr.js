function M(e){if(!e)return 0;const n=/```[\s\S]*?```/g;let t=0,o=e;const s=e.match(n);if(s)for(const i of s)t+=Math.ceil(i.length/3.2),o=o.replace(i,"");return Math.ceil(o.length/4)+t}function W(e){let n=0;for(const t of e)n+=M(t.text),n+=4;return n}function F(e){return e>=1e6?`${(e/1e6).toFixed(1)}M`:e>=1e3?`${(e/1e3).toFixed(1)}k`:String(e)}const G=/```[\s\S]*?```/g,K=/\b(error|bug|issue|problem|fails?|failing|broken|todo|doesn't work|not working|exception|crash|undefined|null reference)\b/i,Y=/\b(must|please make sure|don't|do not|never|always|prefer|should not|avoid|requirement|important)\b/i,J=/\b(instead of|rather than|avoid using|don't use|won't use|didn't work|that doesn't|wrong approach)\b/i,z=/\b(I've|I have|created|added|implemented|fixed|updated|wrote|built|set up|configured|refactored|migrated|deployed)\b/i,V=/\b[\w-]+\.(ts|tsx|js|jsx|py|rs|go|java|css|html|json|yaml|yml|toml|md|sql)\b/g;function de(e,n){var T,x,d;const t=e.filter(l=>l.role==="user"),o=e.filter(l=>l.role==="assistant"),s=((T=t[0])==null?void 0:T.text)??"",r=((x=t.at(-1))==null?void 0:x.text)??"",i=((d=o.at(-1))==null?void 0:d.text)??"",c=_(o,z,10),h=_(e,K,8),m=_(t,Y,8),w=_(e,J,6),v=X(o,5),k=Z(i),p=q(e),S=W(e),a=[];return a.push("# Session Handoff Brief"),a.push(""),a.push(`_Captured from **${n.sourceSite??"unknown"}** on ${new Date().toLocaleString()} · ${e.length} messages · ~${F(S)} tokens_`),n.title&&a.push(`_Page: ${n.title}_`),a.push(""),a.push("You are continuing a previous AI-assisted working session. Do **not** restart from scratch. Read this brief carefully, then continue from the exact current state described below."),a.push(""),a.push("## Role for the New Assistant"),a.push("Continue as the same kind of assistant this task needs — infer from the context below (technical / product / writing / research / debugging)."),a.push(""),a.push("## Project / Task Summary"),a.push(R(s,800)||"_Not captured — add manually._"),a.push(""),a.push("## Current Objective"),a.push(R(r,600)||"_Not captured — add manually._"),a.push(""),a.push("## Completed Work"),a.push(c.length?g(c):"_None auto-detected — review transcript and add manually._"),a.push(""),p.length>0&&(a.push("## Files Referenced"),a.push(g(p.slice(0,20))),a.push("")),a.push("## Current Code / State"),a.push(v.length?v.join(`

`):"_No code blocks auto-detected._"),a.push(""),a.push("## Known Issues / Open Problems"),a.push(h.length?g(h):"_None auto-detected._"),a.push(""),a.push("## Constraints and Preferences"),a.push(m.length?g(m):"_None auto-detected._"),a.push(""),a.push("## What NOT to Repeat"),a.push(w.length?g(w):"_None auto-detected._"),a.push(""),a.push("## Exact Next Action"),a.push(R(i,600)||"_Not captured — state the next step manually._"),a.push(""),a.push("## Open Questions for the User"),a.push(k.length?g(k):"_None auto-detected._"),a.push(""),a.push("---"),a.push(`_Auto-generated from ${e.length} messages using rule-based heuristics (not an LLM). Review and edit before pasting into a new session._`),a.join(`
`)}function Q(e){const n=e.map(s=>s.text).join(" "),t=e.some(s=>s.codeBlocks.length>0),o=K.test(n);return t&&o?"debugging":t?"coding":/\b(paper|article|essay|blog|write|draft|paragraph|chapter|edit)\b/i.test(n)?"writing":/\b(research|study|analysis|data|findings|hypothesis|methodology)\b/i.test(n)?"research":"general"}function _(e,n,t){const o=[];for(const s of e){const r=s.text.split(new RegExp("(?<=[.!?])\\s+"));for(const i of r){const c=i.trim();if(n.test(c)&&c.length>10&&c.length<400&&(o.push(c),o.length>=t))return o}}return o}function X(e,n){const t=[];for(const o of[...e].reverse()){const s=o.text.match(G);if(s){for(const r of s)if(t.push(r),t.length>=n)return t.reverse()}}return t.reverse()}function Z(e,n){return e?e.split(new RegExp("(?<=[.!?])\\s+")).filter(t=>t.trim().endsWith("?")).slice(-5):[]}function q(e){const n=new Set;for(const t of e){const o=t.text.match(V);if(o)for(const s of o)n.add(s)}return Array.from(n)}function g(e){return e.map(n=>"- "+n).join(`
`)}function R(e,n){return e?(e=e.trim(),e.length>n?e.slice(0,n)+"…":e):""}const A="AES-GCM",ee=256,P="__sh_enc_key__";async function L(){const e=await chrome.storage.local.get(P);if(e[P]){const s=Uint8Array.from(atob(e[P]),r=>r.charCodeAt(0));return crypto.subtle.importKey("raw",s,A,!1,["encrypt","decrypt"])}const n=await crypto.subtle.generateKey({name:A,length:ee},!0,["encrypt","decrypt"]),t=await crypto.subtle.exportKey("raw",n),o=btoa(String.fromCharCode(...new Uint8Array(t)));return await chrome.storage.local.set({[P]:o}),n}async function te(e){const n=await L(),t=crypto.getRandomValues(new Uint8Array(12)),o=new TextEncoder().encode(e),s=await crypto.subtle.encrypt({name:A,iv:t},n,o);return{ciphertext:btoa(String.fromCharCode(...new Uint8Array(s))),iv:btoa(String.fromCharCode(...new Uint8Array(t)))}}async function B(e,n){const t=await L(),o=Uint8Array.from(atob(n),i=>i.charCodeAt(0)),s=Uint8Array.from(atob(e),i=>i.charCodeAt(0)),r=await crypto.subtle.decrypt({name:A,iv:o},t,s);return new TextDecoder().decode(r)}const he=Object.freeze(Object.defineProperty({__proto__:null,decrypt:B,encrypt:te},Symbol.toStringTag,{value:"Module"})),u={SNAPSHOTS:"sh_snapshots",PROJECTS:"sh_projects",SETTINGS:"sh_settings",API_KEYS:"sh_api_keys"},ne={captureSession:"Ctrl+Shift+C",openSidePanel:"Ctrl+Shift+H",injectLastSnapshot:"Ctrl+Shift+I",saveCurrentBrief:"Ctrl+S"},oe={theme:"system",defaultMode:"rule-based",llmProvider:"groq",llmModel:"openai/gpt-oss-120b",fallbackOrder:["groq","openai","gemini"],showInPageButton:!0,autoInjectEnabled:!0,contextWarningEnabled:!0,contextWarningThreshold:.7,notificationsEnabled:!0,defaultProjectId:"default",shortcuts:ne},$={id:"default",name:"General",color:"#6366f1",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),snapshotCount:0};async function O(e,n){return(await chrome.storage.local.get(e))[e]??n}async function y(e,n){await chrome.storage.local.set({[e]:n})}async function b(){return O(u.SNAPSHOTS,[])}async function me(e){const n=await b(),t=n.findIndex(o=>o.id===e.id);t>=0?n[t]={...e,updatedAt:new Date().toISOString(),version:n[t].version+1}:n.unshift(e),await y(u.SNAPSHOTS,n),await U(e.projectId)}async function fe(e){const n=await b(),t=n.find(s=>s.id===e),o=n.filter(s=>s.id!==e);await y(u.SNAPSHOTS,o),t&&await U(t.projectId)}async function ge(e){return(await b()).find(t=>t.id===e)}async function ye(e){const n=await b();if(!e.trim())return n.filter(o=>!o.isArchived);const t=e.toLowerCase();return n.filter(o=>!o.isArchived&&(o.name.toLowerCase().includes(t)||o.brief.toLowerCase().includes(t)||o.tags.some(s=>s.toLowerCase().includes(t))||o.pageTitle.toLowerCase().includes(t)))}async function se(){const e=await O(u.PROJECTS,[]);return e.length?e:(await y(u.PROJECTS,[$]),[$])}async function U(e){const n=await se(),t=await b(),o=n.find(s=>s.id===e);o&&(o.snapshotCount=t.filter(s=>s.projectId===e&&!s.isArchived).length,await y(u.PROJECTS,n))}async function I(){return O(u.SETTINGS,oe)}async function we(e){const n=await I();await y(u.SETTINGS,{...n,...e})}async function D(){return O(u.API_KEYS,{})}async function ke(e,n){const t=await D();t[e]=n,await y(u.API_KEYS,t)}function Se(){return Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,9)}const N={groq:{provider:"groq",displayName:"Groq",apiKeyRequired:!0,apiUrl:"https://api.groq.com/openai/v1/chat/completions",defaultModel:"openai/gpt-oss-120b",availableModels:["openai/gpt-oss-120b","openai/gpt-oss-20b"],maxTokens:65536,costPer1kInput:15e-5,costPer1kOutput:6e-4},openai:{provider:"openai",displayName:"OpenAI",apiKeyRequired:!0,apiUrl:"https://api.openai.com/v1/chat/completions",defaultModel:"gpt-4o-mini",availableModels:["gpt-4o","gpt-4o-mini","gpt-4-turbo"],maxTokens:16384,costPer1kInput:15e-5,costPer1kOutput:6e-4},anthropic:{provider:"anthropic",displayName:"Anthropic",apiKeyRequired:!0,apiUrl:"https://api.anthropic.com/v1/messages",defaultModel:"claude-3-5-sonnet-20241022",availableModels:["claude-3-5-sonnet-20241022","claude-3-5-haiku-20241022","claude-3-haiku-20240307"],maxTokens:8192,costPer1kInput:.003,costPer1kOutput:.015},gemini:{provider:"gemini",displayName:"Google Gemini",apiKeyRequired:!0,apiUrl:"https://generativelanguage.googleapis.com/v1beta/models",defaultModel:"gemini-2.0-flash",availableModels:["gemini-2.0-flash","gemini-1.5-flash","gemini-1.5-pro"],maxTokens:8192,costPer1kInput:75e-6,costPer1kOutput:3e-4},ollama:{provider:"ollama",displayName:"Ollama (Local)",apiKeyRequired:!1,apiUrl:"http://localhost:11434/api/chat",defaultModel:"mistral",availableModels:["mistral","phi3","gemma2"],maxTokens:4096}},ae={coding:`You are an expert code assistant creating a "Session Handoff Brief" from a programming chat transcript.
Preserve EXACT function names, variable names, file paths, error messages, and stack traces.
Extract the project structure, current file contents, recent diffs, and dependencies.
Output in this Markdown format:

## Role for the New Assistant
[Specific technical role, e.g., "Senior React/TypeScript Developer"]

## Project / Task Summary
[Clear summary including tech stack and architecture]

## Current Objective
[Exact current coding task]

## Completed Work
[Bulleted list of completed items with file names]

## Files & Code State
[Key file contents, recent changes]

## Known Issues / Blockers
[Exact error messages, stack traces, failing tests]

## Constraints & Architecture Decisions
[Tech choices, patterns, requirements]

## Next Steps
[Specific next coding tasks]`,debugging:`You are creating a "Session Handoff Brief" from a debugging session.
Focus on: the exact error, what was tried, what was ruled out, and the current hypothesis.
Preserve ALL error messages, stack traces, and log output VERBATIM.
Output in this Markdown format:

## Role for the New Assistant
[e.g., "Debugging specialist for Node.js/React applications"]

## The Bug
[Clear description of the problem]

## Error Details
[Exact error messages, stack traces, logs]

## Environment
[OS, runtime versions, relevant config]

## What Was Tried
[Numbered list of attempted fixes and their results]

## What Was Ruled Out
[Approaches that didn't work and why]

## Current Hypothesis
[The leading theory for the root cause]

## Next Steps
[What to try next]`,writing:`You are creating a "Session Handoff Brief" from a writing/editing session.
Preserve the writing style, tone decisions, structural choices, and feedback incorporated.
Output in this Markdown format:

## Role for the New Assistant
[e.g., "Technical writer specializing in developer documentation"]

## Project Summary
[What's being written, for whom]

## Current State
[Draft status, word count, sections completed]

## Style & Tone Guidelines
[Voice, audience level, formatting preferences]

## Key Decisions Made
[Structural and content choices]

## Feedback Incorporated
[Changes made based on review]

## Next Steps
[What to write/edit next]`,research:`You are creating a "Session Handoff Brief" from a research/analysis session.
Preserve sources, findings, methodologies, and analytical frameworks discussed.
Output in this Markdown format:

## Role for the New Assistant
[e.g., "Research analyst specializing in market analysis"]

## Research Topic
[Clear statement of the research question]

## Findings So Far
[Key discoveries with sources]

## Methodology
[Approach used for analysis]

## Data & Sources
[Links, papers, datasets referenced]

## Open Questions
[Unresolved research questions]

## Next Steps
[What to investigate next]`,general:`You are creating a "Session Handoff Brief" from a chat transcript.
Summarize with HIGH ACCURACY. Preserve exact names, specific details, and nuanced decisions.
Output in this Markdown format:

## Role for the New Assistant
[Infer the appropriate role]

## Task Summary
[Clear summary of the overall task]

## Current Objective
[What was being worked on at the end]

## Completed Work
[What has been accomplished]

## Key Decisions
[Important choices and their rationale]

## Known Issues
[Current problems or blockers]

## Next Steps
[What needs to happen next]`};async function E(e){var t;const n=N[e.provider];return e.apiKey=((t=e.apiKey)==null?void 0:t.replace(/[^\x20-\x7E]/g,""))||"",e.provider==="anthropic"?ie(e):e.provider==="gemini"?ce(e):e.provider==="ollama"?le(e):re(e,n)}async function re(e,n){var s,r,i;const t=await fetch(n.apiUrl,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e.apiKey}`},body:JSON.stringify({model:e.model,messages:[{role:"system",content:e.systemPrompt},{role:"user",content:e.userPrompt}],temperature:e.temperature,max_tokens:e.maxTokens})});if(!t.ok){const c=await t.json().catch(()=>({}));throw new Error(`${n.displayName} API Error: ${t.status} - ${((s=c.error)==null?void 0:s.message)??t.statusText}`)}const o=await t.json();return{content:o.choices[0].message.content,inputTokens:((r=o.usage)==null?void 0:r.prompt_tokens)??0,outputTokens:((i=o.usage)==null?void 0:i.completion_tokens)??0,model:e.model,provider:e.provider}}async function ie(e,n){var s,r;const t=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","x-api-key":e.apiKey,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:e.model,max_tokens:e.maxTokens,system:e.systemPrompt,messages:[{role:"user",content:e.userPrompt}],temperature:e.temperature})});if(!t.ok){const i=await t.json().catch(()=>({}));throw new Error(`Anthropic API Error: ${t.status} - ${i.message??t.statusText}`)}const o=await t.json();return{content:o.content[0].text,inputTokens:((s=o.usage)==null?void 0:s.input_tokens)??0,outputTokens:((r=o.usage)==null?void 0:r.output_tokens)??0,model:e.model,provider:"anthropic"}}async function ce(e,n){var r,i,c;const t=`https://generativelanguage.googleapis.com/v1beta/models/${e.model}:generateContent?key=${e.apiKey}`,o=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({system_instruction:{parts:[{text:e.systemPrompt}]},contents:[{parts:[{text:e.userPrompt}]}],generationConfig:{temperature:e.temperature,maxOutputTokens:e.maxTokens}})});if(!o.ok){const h=await o.json().catch(()=>({}));throw new Error(`Gemini API Error: ${o.status} - ${((r=h.error)==null?void 0:r.message)??o.statusText}`)}const s=await o.json();return{content:s.candidates[0].content.parts[0].text,inputTokens:((i=s.usageMetadata)==null?void 0:i.promptTokenCount)??0,outputTokens:((c=s.usageMetadata)==null?void 0:c.candidatesTokenCount)??0,model:e.model,provider:"gemini"}}async function le(e,n){const t=await fetch("http://localhost:11434/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:e.model,messages:[{role:"system",content:e.systemPrompt},{role:"user",content:e.userPrompt}],stream:!1,options:{temperature:e.temperature,num_predict:e.maxTokens}})});if(!t.ok)throw new Error(`Ollama Error: ${t.status} - ${t.statusText}`);const o=await t.json();return{content:o.message.content,inputTokens:o.prompt_eval_count??0,outputTokens:o.eval_count??0,model:e.model,provider:"ollama"}}function ue(e,n=6e3){if(e.length===0)return[];const t=[];let o=[],s=0;for(const r of e){const i=M(r.text)+4;s+i>n&&o.length>0&&(t.push(o),o=[],s=0),o.push(r),s+=i}return o.length>0&&t.push(o),t}async function H(e){const t=(await D())[e];if(!t)throw new Error(`No API key configured for ${e}`);return B(t.ciphertext,t.iv)}async function pe(e,n,t,o){const s=await I(),r=t??s.llmProvider,i=N[r],c=o??(s.llmModel&&i.availableModels.includes(s.llmModel)?s.llmModel:i.defaultModel),h=Q(e),m=i.apiKeyRequired?await H(r):"",w=ae[h],v=M(e.map(l=>l.text).join(`
`)),k=(i.maxTokens??3e4)*.7;if(v<=k){const l=e.map(f=>`**${f.role.toUpperCase()}**: ${f.text}`).join(`

---

`),C=await E({provider:r,apiKey:m,model:c,systemPrompt:w,userPrompt:`Here is the transcript to summarize:

${l}`,maxTokens:3e3,temperature:.1});return{brief:C.content,stats:C}}const p=ue(e,Math.floor(k*.8)),S=[];let a=0,T=0;for(let l=0;l<p.length;l++){const C=p[l].map(j=>`**${j.role.toUpperCase()}**: ${j.text}`).join(`

---

`),f=await E({provider:r,apiKey:m,model:c,systemPrompt:`You are summarizing part ${l+1} of ${p.length} of a chat transcript. Capture all key details, decisions, code changes, and action items from this segment. Be thorough but concise.`,userPrompt:C,maxTokens:2e3,temperature:.1});S.push({chunkIndex:l,summary:f.content,messageRange:[0,p[l].length-1]}),a+=f.inputTokens,T+=f.outputTokens}const x=S.map(l=>`### Part ${l.chunkIndex+1}
${l.summary}`).join(`

---

`),d=await E({provider:r,apiKey:m,model:c,systemPrompt:w,userPrompt:`Below are summaries of ${S.length} sequential parts of a long conversation. Synthesize them into a single, comprehensive handoff brief:

${x}`,maxTokens:3e3,temperature:.1});return{brief:d.content,stats:{content:d.content,inputTokens:a+d.inputTokens,outputTokens:T+d.outputTokens,model:c,provider:r}}}async function Te(e,n){const t=await I(),o=[t.llmProvider,...t.fallbackOrder.filter(s=>s!==t.llmProvider)];for(const s of o)try{const r=N[s];return n==null||n(`Trying ${r.displayName}...`),await pe(e,n,s,r.defaultModel)}catch{continue}throw new Error("All LLM providers failed. Please check your API keys and try again.")}async function be(e,n){const t=N[e];let o=n==null?void 0:n.trim();if(!o&&t.apiKeyRequired)try{o=await H(e)}catch(r){return{success:!1,message:r.message,model:t.defaultModel}}const s=t.defaultModel;try{return{success:!0,message:(await E({provider:e,apiKey:o||"",model:s,systemPrompt:"You are a test assistant.",userPrompt:'Reply with the single word "CONNECTED".',maxTokens:10,temperature:0})).content.trim(),model:s}}catch(r){return{success:!1,message:r.message,model:s}}}export{N as P,Te as a,de as b,Se as c,b as d,ge as e,we as f,I as g,ke as h,ye as i,fe as j,D as k,he as l,me as s,be as t};
